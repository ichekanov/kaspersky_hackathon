import json
import random

import paho.mqtt.subscribe as subscribe
import paho.mqtt.publish as publish

from Homography import screenToWorld

broker = '10.0.0.2'
port = 1883
topic = "python/mqtt"
# generate client ID with pub prefix randomly
client_id = f'python-mqtt-{random.randint(0, 1000)}'

test_json = {
    "cmd": "auto",
    "markers_screen": [{"id": "0", "x": "102.0", "y": "603.0"}, {"id": "2", "x": "375.0", "y": "347.0"},
                       {"id": "3", "x": "860.0", "y": "342.0"}, {"id": "4", "x": "1038.0", "y": "610.0"}],
    "markers_floor": [{"id": "0", "x": "1.0", "y": "4.0"}, {"id": "2", "x": "1.0", "y": "1.0"},
                      {"id": "3", "x": "4.0", "y": "1.0"}, {"id": "4", "x": "4.0", "y": "4.0"}],
    "targets_screen": [{"id": "2", "x": "470.0", "y": "475.0"},
                       {"id": "3", "x": "703.0", "y": "400.0"}, {"id": "4", "x": "706.0", "y": "480.0"},
                       {"id": "5", "x": "717.0", "y": "606.0"}],
    "robot_screen": [{"id": "0", "x": "511.0", "y": "400.0"}]
}


# username = 'emqx'
# password = 'public'

def fromPoint(p):
    return [p["id"], p["x"], p["y"]]

def toPoint(a,b):
    return {"id": a, "x": str(b[0]), "y": str(b[1])}

def sendUpdatedPoints(client, userdata, message):
    try:
        j = json.loads(message.payload)


        if j["cmd"] != "auto":
            print("Transmitted mqtt message with payload:\n", message.payload)
            publish.single("abot/command2", message.payload, hostname="10.0.2.2")
        else:
            ids = []
            marks_screen = []
            marks_world = []
            waypoints_screen = fromPoint(j["robot_screen"][0])
            ids.append(waypoints_screen[0])
            waypoints_screen = [waypoints_screen[1:]]


            for i in j["targets_screen"]:
                ids.append(i["id"])
                waypoints_screen.append(fromPoint(i)[1:])

            for i in j["markers_screen"]:
                marks_screen.append(fromPoint(i)[1:])

            for i in j["markers_floor"]:
                marks_world.append(fromPoint(i)[1:])

            waypoints_world = list(screenToWorld(waypoints_screen, marks_screen, marks_world))

            j["robot_floor"] = [toPoint(j["robot_screen"][0]["id"], waypoints_world[0][0])]

            j["targets_floor"] = []
            for i in waypoints_world[1:]:
                j["targets_floor"].append(toPoint(ids[0], i[0]))
                ids.pop(0)

            res = json.dumps(j)
            print("Transmitted mqtt message with payload:\n", res)
            publish.single("abot/command2", res, hostname="10.0.2.2")
    except:
        print(1)







def main():
    subscribe.callback(sendUpdatedPoints, "abot/command", hostname="10.0.2.2")


if __name__ == '__main__':
    main()
    # sendUpdatedPoints(1,1,json.dumps(test_json))
